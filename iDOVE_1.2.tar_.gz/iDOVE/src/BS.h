arma::rowvec BS(int t, arma::ivec knots, bool constantVE);

